import React from 'react';
import { motion } from 'motion/react';
import { 
  Home, 
  FileText, 
  Activity, 
  PieChart, 
  Settings, 
  LogOut, 
  ChevronRight,
  Menu,
  X
} from 'lucide-react';
import { View, Role } from '../../types';

interface SidebarProps {
  currentView: View;
  onNavigate: (view: View) => void;
  role: Role;
  onLogout: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({ currentView, onNavigate, role, onLogout }) => {
  const pymeLinks = [
    { id: 'pyme-dashboard', label: 'Inicio', icon: <Home size={20} /> },
    { id: 'pyme-wizard', label: 'Mi Solicitud', icon: <FileText size={20} /> },
    { id: 'pyme-score', label: 'Mi SafetyScore', icon: <Activity size={20} /> },
    { id: 'pyme-finances', label: 'Mis Finanzas', icon: <PieChart size={20} /> },
  ];

  const investorLinks = [
    { id: 'investor-portfolio', label: 'Mi Portafolio', icon: <PieChart size={20} /> },
    { id: 'investor-marketplace', label: 'Marketplace', icon: <Home size={20} /> },
    { id: 'investor-alerts', label: 'Alertas', icon: <Activity size={20} /> },
  ];

  const links = role === 'pyme' ? pymeLinks : investorLinks;

  return (
    <aside className="fixed left-0 top-0 h-screen w-72 bg-white border-r border-slate-100 flex flex-col z-50 shadow-sm">
      <div className="p-8">
        <div className="flex items-center gap-2 mb-12">
          <div className="w-8 h-8 bg-brand-blue rounded-lg flex items-center justify-center font-bold text-white shadow-lg shadow-brand-blue/20">S</div>
          <span className="text-xl font-display font-bold text-brand-blue">SafetyScore</span>
        </div>

        <nav className="space-y-2">
          {links.map((link) => (
            <button
              key={link.id}
              onClick={() => onNavigate(link.id as View)}
              className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all ${
                currentView === link.id 
                  ? 'bg-brand-blue/10 text-brand-blue border border-brand-blue/10 font-semibold' 
                  : 'text-slate-500 hover:text-brand-blue hover:bg-slate-50'
              }`}
            >
              {link.icon}
              <span>{link.label}</span>
              {currentView === link.id && (
                <motion.div layoutId="sidebar-active" className="ml-auto">
                  <ChevronRight size={16} />
                </motion.div>
              )}
            </button>
          ))}
        </nav>
      </div>

      <div className="mt-auto p-8 space-y-4">
        <button className="w-full flex items-center gap-3 px-4 py-3 rounded-xl text-slate-500 hover:text-brand-blue hover:bg-slate-50 transition-all">
          <Settings size={20} />
          <span>Configuración</span>
        </button>
        
        <div className="pt-4 border-t border-slate-100 flex items-center gap-3">
          <div className="w-10 h-10 rounded-full bg-slate-100 border border-slate-200 flex items-center justify-center text-slate-500 font-bold shadow-sm">
            {role === 'pyme' ? 'DJ' : 'IA'}
          </div>
          <div className="flex-1 min-w-0">
            <div className="text-sm font-bold text-brand-blue truncate">
              {role === 'pyme' ? 'Don José' : 'Inv. Institucional'}
            </div>
            <div className="text-xs text-slate-400 truncate">
              {role === 'pyme' ? 'Abarrotes Doña María' : 'Premium Member'}
            </div>
          </div>
          <button 
            onClick={onLogout}
            className="p-2 text-slate-400 hover:text-brand-red transition-colors"
          >
            <LogOut size={18} />
          </button>
        </div>
      </div>
    </aside>
  );
};
