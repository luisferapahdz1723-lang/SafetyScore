import React, { useState } from 'react';
import { motion } from 'motion/react';
import { 
  Search, 
  Filter, 
  MapPin, 
  TrendingUp, 
  Clock, 
  ArrowRight,
  LayoutGrid,
  List as ListIcon,
  ChevronDown
} from 'lucide-react';
import { Header } from '../common/Header';
import { MOCK_OPPORTUNITIES } from '../../constants';
import { BusinessOpportunity, View } from '../../types';

interface InvestorMarketplaceProps {
  onSelectOpportunity: (opp: BusinessOpportunity) => void;
}

export const InvestorMarketplace: React.FC<InvestorMarketplaceProps> = ({ onSelectOpportunity }) => {
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');

  return (
    <div className="max-w-7xl mx-auto">
      <Header 
        title="TERMINAL DE MERCADO" 
        subtitle="Explora negocios verificados por IA y diversifica tu portafolio." 
      />

      <div className="flex flex-col lg:flex-row gap-6">
        {/* Sidebar Filters */}
        <aside className="lg:w-64 space-y-4">
          <div className="glass-panel p-4 space-y-6 border-slate-800">
            <div className="flex items-center justify-between border-b border-slate-800 pb-2">
              <h3 className="font-mono text-xs font-bold text-slate-400 flex items-center gap-2 uppercase tracking-tighter">
                <Filter size={14} />
                Filtros de Búsqueda
              </h3>
              <button className="text-[10px] text-primary hover:underline font-mono">RESET</button>
            </div>

            <div className="space-y-6">
              <div className="space-y-3">
                <label className="text-[10px] font-mono font-bold text-slate-500 uppercase tracking-tighter">SafetyScore Mínimo</label>
                <input type="range" className="w-full accent-primary" min="0" max="100" />
                <div className="flex justify-between text-[10px] text-slate-500 font-mono">
                  <span>0.00</span>
                  <span>100.00</span>
                </div>
              </div>

              <div className="space-y-3">
                <label className="text-[10px] font-mono font-bold text-slate-500 uppercase tracking-tighter">Sector Económico</label>
                <div className="space-y-1">
                  {['Abarrotes', 'Farmacia', 'Papelería', 'Taller', 'Servicios'].map((sector) => (
                    <label key={sector} className="flex items-center gap-2 text-xs text-slate-400 cursor-pointer hover:text-primary transition-colors font-mono">
                      <input type="checkbox" className="w-3 h-3 rounded border-slate-700 bg-slate-800 accent-primary" />
                      {sector.toUpperCase()}
                    </label>
                  ))}
                </div>
              </div>

              <div className="space-y-3">
                <label className="text-[10px] font-mono font-bold text-slate-500 uppercase tracking-tighter">ROI Esperado (MIN)</label>
                <div className="flex items-center gap-2">
                  <input type="number" placeholder="5.00" className="input-field w-full py-1 text-xs font-mono border-slate-800" />
                  <span className="text-slate-500 font-mono text-xs">%</span>
                </div>
              </div>
            </div>

            <button className="btn-primary w-full py-2 text-xs font-mono rounded-none uppercase tracking-widest">
              Ejecutar Filtro
            </button>
          </div>
        </aside>

        {/* Main Content */}
        <div className="flex-1 space-y-4">
          {/* Top Bar */}
          <div className="flex flex-col sm:flex-row gap-4 justify-between items-center bg-slate-900/50 p-2 border border-slate-800">
            <div className="relative flex-1 w-full">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-500" size={14} />
              <input 
                type="text" 
                placeholder="BUSCAR TICKER / SECTOR / UBICACIÓN..." 
                className="bg-transparent border-none w-full pl-10 py-1 text-xs font-mono text-slate-300 focus:ring-0 placeholder:text-slate-600"
              />
            </div>
            <div className="flex items-center gap-2">
              <div className="flex bg-slate-950 p-1 border border-slate-800">
                <button 
                  onClick={() => setViewMode('grid')}
                  className={`p-1 transition-all ${viewMode === 'grid' ? 'bg-primary text-white' : 'text-slate-600 hover:text-slate-400'}`}
                >
                  <LayoutGrid size={16} />
                </button>
                <button 
                  onClick={() => setViewMode('list')}
                  className={`p-1 transition-all ${viewMode === 'list' ? 'bg-primary text-white' : 'text-slate-600 hover:text-slate-400'}`}
                >
                  <ListIcon size={16} />
                </button>
              </div>
              <button className="text-[10px] font-mono border border-slate-800 px-3 py-1.5 text-slate-400 flex items-center gap-2 hover:bg-slate-800">
                ORDENAR: SCORE
                <ChevronDown size={12} />
              </button>
            </div>
          </div>

          {/* Grid of Opportunities */}
          <div className="grid md:grid-cols-2 xl:grid-cols-3 gap-4">
            {MOCK_OPPORTUNITIES.map((opp, i) => (
              <motion.div
                key={opp.id}
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: i * 0.05 }}
                onClick={() => onSelectOpportunity(opp)}
                className="glass-panel p-4 group cursor-pointer border-slate-800 hover:border-primary/50 transition-colors rounded-none relative"
              >
                <div className="flex justify-between items-start mb-4">
                  <div>
                    <div className="text-[10px] font-mono text-primary mb-1">#{opp.id.toUpperCase()}</div>
                    <h3 className="text-sm font-bold text-slate-200 group-hover:text-primary transition-colors uppercase tracking-tight">{opp.name}</h3>
                    <div className="flex items-center gap-1 text-[10px] text-slate-500 mt-1 font-mono">
                      <MapPin size={10} />
                      {opp.location.toUpperCase()}
                    </div>
                  </div>
                  <div className={`text-2xl font-mono font-bold ${
                    opp.safetyScore > 80 ? 'text-emerald-500' :
                    opp.safetyScore > 70 ? 'text-amber-500' :
                    'text-rose-500'
                  }`}>
                    {opp.safetyScore.toFixed(1)}
                  </div>
                </div>

                <div className="grid grid-cols-3 gap-2 mb-4 py-3 border-y border-slate-800/50">
                  <div>
                    <div className="text-[9px] text-slate-600 font-mono uppercase mb-1">ROI_EST</div>
                    <div className="text-xs font-mono font-bold text-slate-300">{opp.roi.toFixed(2)}%</div>
                  </div>
                  <div>
                    <div className="text-[9px] text-slate-600 font-mono uppercase mb-1">CAP_REQ</div>
                    <div className="text-xs font-mono font-bold text-slate-300">${(opp.amount / 1000).toFixed(1)}K</div>
                  </div>
                  <div>
                    <div className="text-[9px] text-slate-600 font-mono uppercase mb-1">TERM_M</div>
                    <div className="text-xs font-mono font-bold text-slate-300">{opp.term}</div>
                  </div>
                </div>

                <div className="space-y-1.5 mb-4">
                  <div className="flex justify-between text-[9px] font-mono uppercase">
                    <span className="text-slate-600">Funding_Progress</span>
                    <span className="text-primary">{opp.fundedPercentage}%</span>
                  </div>
                  <div className="h-1 w-full bg-slate-800 overflow-hidden">
                    <motion.div 
                      className="h-full bg-primary"
                      initial={{ width: 0 }}
                      animate={{ width: `${opp.fundedPercentage}%` }}
                    />
                  </div>
                </div>

                <div className="flex items-center justify-between">
                  <div className={`px-1.5 py-0.5 text-[9px] font-mono font-bold border ${
                    opp.status === 'new' ? 'border-primary/30 text-primary' :
                    opp.status === 'high-demand' ? 'border-amber-500/30 text-amber-500' :
                    'border-rose-500/30 text-rose-500'
                  }`}>
                    {opp.status.toUpperCase()}
                  </div>
                  <div className="text-slate-500 text-[10px] font-mono flex items-center gap-1 group-hover:text-primary transition-colors">
                    ANALYZE_PROSPECTUS
                    <ArrowRight size={12} />
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
