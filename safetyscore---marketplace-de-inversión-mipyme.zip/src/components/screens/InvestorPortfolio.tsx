import React from 'react';
import { motion } from 'motion/react';
import { 
  TrendingUp, 
  DollarSign, 
  PieChart, 
  Activity, 
  ArrowUpRight,
  CheckCircle2,
  Clock,
  AlertCircle,
  ChevronRight
} from 'lucide-react';
import { Header } from '../common/Header';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, AreaChart, Area } from 'recharts';

const MOCK_PERFORMANCE = [
  { month: 'Oct', value: 420000 },
  { month: 'Nov', value: 435000 },
  { month: 'Dic', value: 450000 },
  { month: 'Ene', value: 462000 },
  { month: 'Feb', value: 475000 },
  { month: 'Mar', value: 485000 },
];

export const InvestorPortfolio: React.FC = () => {
  return (
    <div className="max-w-7xl mx-auto">
      <Header 
        title="TERMINAL DE PORTAFOLIO" 
        subtitle="Monitoreo en tiempo real de tus inversiones y rendimientos." 
      />

      {/* Global Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
        {[
          { label: 'Capital_Invested', value: '$485,000', icon: <DollarSign className="text-primary" />, trend: '+15.2%' },
          { label: 'Accumulated_Return', value: '$62,300', icon: <TrendingUp className="text-emerald-500" />, trend: '+8.4%' },
          { label: 'Avg_ROI', value: '16.85%', icon: <PieChart className="text-amber-500" />, trend: 'STABLE' },
          { label: 'Active_Assets', value: '05', icon: <Activity className="text-primary" />, trend: '2_CLOSING' }
        ].map((stat, i) => (
          <motion.div
            key={i}
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: i * 0.05 }}
            className="glass-panel p-4 border-slate-800 rounded-none relative overflow-hidden"
          >
            <div className="flex items-center justify-between mb-4">
              <div className="w-8 h-8 bg-slate-900 border border-slate-800 flex items-center justify-center">
                {stat.icon}
              </div>
              <div className="text-[9px] font-mono font-bold px-1.5 py-0.5 border border-slate-800 text-slate-500">
                {stat.trend}
              </div>
            </div>
            <div className="text-[9px] text-slate-500 font-mono uppercase tracking-widest mb-1">{stat.label}</div>
            <div className="text-2xl font-mono font-bold text-slate-100">{stat.value}</div>
          </motion.div>
        ))}
      </div>

      <div className="grid lg:grid-cols-3 gap-6">
        {/* Performance Chart */}
        <div className="lg:col-span-2 glass-panel p-6 border-slate-800 rounded-none">
          <div className="flex items-center justify-between mb-8 border-b border-slate-800 pb-4">
            <h3 className="text-[10px] font-mono font-bold text-slate-400 uppercase tracking-widest">PORTFOLIO_EQUITY_CURVE</h3>
            <div className="flex gap-1">
              {['1M', '3M', '6M', '1Y'].map((p) => (
                <button key={p} className={`px-2 py-1 font-mono text-[10px] transition-all ${p === '6M' ? 'bg-primary text-white' : 'text-slate-600 hover:text-slate-400 border border-slate-800'}`}>
                  {p}
                </button>
              ))}
            </div>
          </div>
          <div className="h-72">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={MOCK_PERFORMANCE}>
                <defs>
                  <linearGradient id="colorValue" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#38bdf8" stopOpacity={0.2}/>
                    <stop offset="95%" stopColor="#38bdf8" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" vertical={false} />
                <XAxis dataKey="month" stroke="#475569" fontSize={10} tickLine={false} axisLine={false} fontClassName="font-mono" />
                <YAxis stroke="#475569" fontSize={10} tickLine={false} axisLine={false} tickFormatter={(v) => `${v/1000}K`} fontClassName="font-mono" />
                <Tooltip 
                  contentStyle={{ backgroundColor: '#020617', border: '1px solid #1e293b', borderRadius: '0', color: '#f8fafc' }}
                  itemStyle={{ color: '#38bdf8', fontSize: '10px', fontFamily: 'monospace' }}
                />
                <Area type="monotone" dataKey="value" stroke="#38bdf8" strokeWidth={2} fillOpacity={1} fill="url(#colorValue)" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Alerts & Notifications */}
        <div className="glass-panel p-6 border-slate-800 rounded-none">
          <h3 className="text-[10px] font-mono font-bold text-slate-400 mb-6 uppercase tracking-widest border-b border-slate-800 pb-4">SYSTEM_ALERTS</h3>
          <div className="space-y-4">
            {[
              { 
                title: 'NEW_OPPORTUNITY', 
                desc: 'Asset detected with ROI > 20.00%.', 
                icon: <TrendingUp size={14} />, 
                color: 'text-emerald-500',
                time: '10M_AGO'
              },
              { 
                title: 'PAYMENT_RECEIVED', 
                desc: 'Abarrotes Doña María: $8,500.00 MXN.', 
                icon: <CheckCircle2 size={14} />, 
                color: 'text-primary',
                time: '02H_AGO'
              },
              { 
                title: 'MATURITY_REMINDER', 
                desc: 'Farmacia San Rafael closes in 48H.', 
                icon: <Clock size={14} />, 
                color: 'text-amber-500',
                time: '05H_AGO'
              },
              { 
                title: 'RISK_ADVISORY', 
                desc: 'Sector benchmark shift: Papelerías.', 
                icon: <AlertCircle size={14} />, 
                color: 'text-rose-500',
                time: '24H_AGO'
              }
            ].map((alert, i) => (
              <div key={i} className="flex gap-3 group cursor-pointer border-b border-slate-800/50 pb-3 last:border-0">
                <div className={`w-8 h-8 bg-slate-950 flex items-center justify-center border border-slate-800 ${alert.color}`}>
                  {alert.icon}
                </div>
                <div className="flex-1">
                  <div className="flex justify-between items-start mb-1">
                    <div className="text-[10px] font-mono font-bold text-slate-300 group-hover:text-primary transition-colors">{alert.title}</div>
                    <div className="text-[8px] text-slate-600 font-mono">{alert.time}</div>
                  </div>
                  <div className="text-[10px] text-slate-500 font-mono leading-tight">{alert.desc}</div>
                </div>
              </div>
            ))}
          </div>
          <button className="w-full mt-6 py-2 text-[10px] font-mono font-bold text-slate-600 hover:text-primary transition-colors flex items-center justify-center gap-2 border-t border-slate-800 pt-4 uppercase">
            VIEW_ALL_LOGS
            <ChevronRight size={12} />
          </button>
        </div>

        {/* Active Investments Table */}
        <div className="lg:col-span-3 glass-panel border-slate-800 rounded-none overflow-hidden">
          <div className="p-4 border-b border-slate-800 flex justify-between items-center bg-slate-900/30">
            <h3 className="text-[10px] font-mono font-bold text-slate-400 uppercase tracking-widest">ACTIVE_POSITIONS_MONITOR</h3>
            <button className="text-[10px] text-primary font-mono font-bold hover:underline uppercase">EXPORT_DATA_CSV</button>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-left font-mono">
              <thead>
                <tr className="bg-slate-950 border-b border-slate-800">
                  <th className="px-6 py-3 text-[9px] font-bold text-slate-500 uppercase tracking-widest">ASSET_NAME</th>
                  <th className="px-6 py-3 text-[9px] font-bold text-slate-500 uppercase tracking-widest">CAPITAL_ALLOC</th>
                  <th className="px-6 py-3 text-[9px] font-bold text-slate-500 uppercase tracking-widest">ROI_EST</th>
                  <th className="px-6 py-3 text-[9px] font-bold text-slate-500 uppercase tracking-widest">STATUS_CODE</th>
                  <th className="px-6 py-3 text-[9px] font-bold text-slate-500 uppercase tracking-widest">SAFETY_SCORE</th>
                  <th className="px-6 py-3 text-[9px] font-bold text-slate-500 uppercase tracking-widest">NEXT_REPAY</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/50">
                {[
                  { name: 'Abarrotes Doña María', amount: '$45,000', roi: '17.30%', status: 'NOMINAL', score: 82.4, next: '15_APR' },
                  { name: 'Farmacia San Rafael', amount: '$120,000', roi: '15.50%', status: 'NOMINAL', score: 88.1, next: '18_APR' },
                  { name: 'Papelería El Estudiante', amount: '$25,000', roi: '19.20%', status: 'PENDING', score: 74.5, next: 'TODAY' },
                  { name: 'Taller Mecánico', amount: '$80,000', roi: '18.50%', status: 'NOMINAL', score: 79.2, next: '22_APR' },
                  { name: 'Panadería La Espiga', amount: '$50,000', roi: '16.00%', status: 'NOMINAL', score: 85.0, next: '25_APR' },
                ].map((row, i) => (
                  <tr key={i} className="hover:bg-slate-900/50 transition-colors cursor-pointer group">
                    <td className="px-6 py-3">
                      <div className="text-xs font-bold text-slate-300 group-hover:text-primary transition-colors uppercase">{row.name}</div>
                    </td>
                    <td className="px-6 py-3 text-xs text-slate-400 font-mono">{row.amount}</td>
                    <td className="px-6 py-3 text-xs text-emerald-500 font-bold">{row.roi}</td>
                    <td className="px-6 py-3">
                      <span className={`px-1.5 py-0.5 border text-[8px] font-bold uppercase ${
                        row.status === 'NOMINAL' ? 'border-emerald-500/30 text-emerald-500' : 'border-rose-500/30 text-rose-500'
                      }`}>
                        {row.status}
                      </span>
                    </td>
                    <td className="px-6 py-3">
                      <div className="flex items-center gap-2">
                        <div className="text-[10px] font-bold text-primary">
                          {row.score.toFixed(1)}
                        </div>
                        <div className="flex-1 h-0.5 w-12 bg-slate-800 overflow-hidden">
                          <div className="h-full bg-emerald-500" style={{ width: `${row.score}%` }} />
                        </div>
                      </div>
                    </td>
                    <td className="px-6 py-3 text-[10px] text-slate-500">{row.next}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
};
