import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  ArrowRight, 
  ArrowLeft, 
  CheckCircle2,
  Sparkles,
  PartyPopper
} from 'lucide-react';

export const PymeWizard: React.FC = () => {
  const [step, setStep] = useState(1);
  const totalSteps = 4;
  const [isSuccess, setIsSuccess] = useState(false);

  const handleNext = () => {
    if (step < totalSteps) {
      setStep(s => s + 1);
    } else {
      setIsSuccess(true);
    }
  };

  if (isSuccess) {
    return (
      <motion.div 
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        className="max-w-2xl mx-auto text-center py-20"
      >
        <div className="w-24 h-24 bg-emerald-100 rounded-full flex items-center justify-center mx-auto mb-8">
          <PartyPopper size={48} className="text-emerald-500" />
        </div>
        <h1 className="text-5xl font-black text-slate-900 mb-6">¡Hicimos Match! 🚀</h1>
        <p className="text-xl text-slate-500 mb-12 leading-relaxed">
          ¡Tenemos buenas noticias! <span className="font-bold text-slate-900">Microfinanciera XYZ</span> quiere invertir en ti.
        </p>
        
        <div className="glass-panel rounded-[2rem] p-8 mb-12 text-left">
          <div className="flex justify-between items-center mb-6 pb-6 border-b border-slate-100">
            <div>
              <div className="text-xs font-bold text-slate-400 uppercase tracking-widest mb-1">Monto ofrecido</div>
              <div className="text-3xl font-black text-slate-900">$200,000 MXN</div>
            </div>
            <div className="text-right">
              <div className="text-xs font-bold text-slate-400 uppercase tracking-widest mb-1">Plazo</div>
              <div className="text-xl font-bold text-slate-900">12 meses</div>
            </div>
          </div>
          <div className="space-y-4">
            <div className="flex items-center gap-3 text-slate-600">
              <CheckCircle2 size={20} className="text-emerald-500" />
              <span>Tasa preferencial por tu SafetyScore</span>
            </div>
            <div className="flex items-center gap-3 text-slate-600">
              <CheckCircle2 size={20} className="text-emerald-500" />
              <span>Sin penalización por pago anticipado</span>
            </div>
          </div>
        </div>

        <div className="flex flex-col gap-4">
          <button className="btn-primary py-5 text-xl rounded-2xl">
            Aceptar y firmar digitalmente
          </button>
          <button className="btn-outline py-5 text-xl rounded-2xl">
            Ver desglose de pagos
          </button>
        </div>
      </motion.div>
    );
  }

  const renderStep = () => {
    switch (step) {
      case 1:
        return (
          <motion.div 
            key="step1"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="space-y-8"
          >
            <h2 className="text-4xl lg:text-5xl font-black text-slate-900 leading-tight">
              ¿Cómo se llama tu negocio?
            </h2>
            <div className="relative">
              <input 
                type="text" 
                placeholder="Ej. Pastelería La Ideal" 
                className="w-full text-3xl lg:text-4xl font-bold bg-transparent border-b-4 border-slate-100 focus:border-emerald-500 outline-none py-4 transition-colors placeholder:text-slate-200"
                autoFocus
              />
            </div>
            <p className="text-slate-400 text-lg italic">
              "Un nombre con historia siempre atrae mejores oportunidades."
            </p>
          </motion.div>
        );
      case 2:
        return (
          <motion.div 
            key="step2"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="space-y-8"
          >
            <h2 className="text-4xl lg:text-5xl font-black text-slate-900 leading-tight">
              ¿Cuánto vendes aproximadamente en un día bueno?
            </h2>
            <div className="relative flex items-center">
              <span className="text-4xl lg:text-5xl font-black text-slate-300 mr-4">$</span>
              <input 
                type="number" 
                placeholder="0.00" 
                className="w-full text-4xl lg:text-5xl font-black bg-transparent border-b-4 border-slate-100 focus:border-emerald-500 outline-none py-4 transition-colors placeholder:text-slate-200"
                autoFocus
              />
            </div>
            <p className="text-slate-400 text-lg">
              No te preocupes si no es exacto, nuestra IA te ayudará a cuadrarlo luego.
            </p>
          </motion.div>
        );
      case 3:
        return (
          <motion.div 
            key="step3"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="space-y-8"
          >
            <h2 className="text-4xl lg:text-5xl font-black text-slate-900 leading-tight">
              ¿Para qué necesitas la inversión?
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {['Inventario', 'Maquinaria', 'Local nuevo', 'Marketing'].map((option) => (
                <button 
                  key={option}
                  className="p-6 text-left rounded-2xl border-2 border-slate-100 hover:border-emerald-500 hover:bg-emerald-50 transition-all group"
                >
                  <div className="text-xl font-bold text-slate-700 group-hover:text-emerald-600">{option}</div>
                </button>
              ))}
            </div>
          </motion.div>
        );
      case 4:
        return (
          <motion.div 
            key="step4"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="space-y-8"
          >
            <div className="w-20 h-20 bg-emerald-100 rounded-full flex items-center justify-center mb-8">
              <Sparkles size={40} className="text-emerald-500" />
            </div>
            <h2 className="text-4xl lg:text-5xl font-black text-slate-900 leading-tight">
              ¡Casi terminamos!
            </h2>
            <p className="text-xl text-slate-500 leading-relaxed">
              Al hacer clic en enviar, nuestra IA analizará tus datos para generar tu <span className="font-bold text-emerald-500">SafetyScore</span> y conectarte con inversionistas.
            </p>
            <div className="p-6 rounded-2xl bg-slate-50 border border-slate-100">
              <div className="flex items-start gap-3">
                <input type="checkbox" className="mt-1 w-6 h-6 accent-emerald-500" id="terms" />
                <label htmlFor="terms" className="text-sm text-slate-600 leading-relaxed">
                  Autorizo el uso de mis datos operativos para la evaluación de crédito virtual.
                </label>
              </div>
            </div>
          </motion.div>
        );
      default:
        return null;
    }
  };

  return (
    <div className="min-h-[80vh] flex flex-col max-w-4xl mx-auto">
      {/* Header / Progress */}
      <div className="mb-20">
        <div className="flex justify-between items-center mb-4">
          <span className="text-sm font-black text-emerald-500 uppercase tracking-widest">Paso {step} de {totalSteps}</span>
          <span className="text-sm font-bold text-slate-400">{Math.round((step / totalSteps) * 100)}% completado</span>
        </div>
        <div className="h-4 w-full bg-slate-100 rounded-full overflow-hidden">
          <motion.div 
            className="h-full bg-emerald-500"
            initial={{ width: '0%' }}
            animate={{ width: `${(step / totalSteps) * 100}%` }}
            transition={{ type: "spring", stiffness: 50 }}
          />
        </div>
      </div>

      {/* Content */}
      <div className="flex-1">
        <AnimatePresence mode="wait">
          {renderStep()}
        </AnimatePresence>
      </div>

      {/* Footer Navigation */}
      <div className="mt-12 flex items-center gap-6">
        {step > 1 && (
          <button 
            onClick={() => setStep(s => s - 1)}
            className="p-5 rounded-2xl border-2 border-slate-100 text-slate-400 hover:bg-slate-50 transition-all"
          >
            <ArrowLeft size={32} />
          </button>
        )}
        <button 
          onClick={handleNext}
          className="flex-1 btn-primary py-6 text-2xl rounded-[2rem] shadow-xl shadow-emerald-500/20"
        >
          {step === totalSteps ? 'Enviar a Evaluación' : 'Continuar'}
          <ArrowRight size={32} />
        </button>
      </div>
    </div>
  );
};
