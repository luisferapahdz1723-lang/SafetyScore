import React from 'react';
import { motion } from 'motion/react';
import { 
  TrendingUp, 
  CheckCircle2, 
  ArrowUpRight,
  Activity,
  Edit3,
  Link as LinkIcon,
  Users
} from 'lucide-react';

export const PymeDashboard: React.FC = () => {
  return (
    <div className="max-w-4xl mx-auto">
      <div className="mb-12">
        <h1 className="text-4xl font-black text-slate-900 mb-2">Hola, Pastelería La Ideal 🍰</h1>
        <p className="text-slate-500 text-lg">Aquí está el resumen de tu salud financiera hoy.</p>
      </div>

      {/* Status Card (Hero) */}
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="glass-panel rounded-[2.5rem] p-10 mb-12 relative overflow-hidden"
      >
        <div className="relative z-10 flex flex-col md:flex-row items-center gap-12">
          <div className="relative w-48 h-48">
            <svg className="w-full h-full" viewBox="0 0 100 100">
              <circle cx="50" cy="50" r="45" fill="none" stroke="#F1F5F9" strokeWidth="10" />
              <motion.circle
                cx="50" cy="50" r="45" fill="none" stroke="#10B981" strokeWidth="10"
                strokeDasharray="282.7"
                initial={{ strokeDashoffset: 282.7 }}
                animate={{ strokeDashoffset: 282.7 * (1 - 88 / 100) }}
                transition={{ duration: 2, ease: "easeOut" }}
                strokeLinecap="round"
                transform="rotate(-90 50 50)"
              />
            </svg>
            <div className="absolute inset-0 flex flex-col items-center justify-center">
              <span className="text-5xl font-black text-slate-900">88</span>
              <span className="text-xs font-bold text-slate-400 uppercase tracking-widest">Score</span>
            </div>
          </div>
          
          <div className="flex-1 text-center md:text-left">
            <div className="inline-block px-4 py-1 rounded-full bg-emerald-100 text-emerald-600 text-sm font-bold mb-4">
              ¡Excelente Salud!
            </div>
            <h2 className="text-3xl font-black text-slate-900 mb-4">¡Estás listo para recibir inversión!</h2>
            <p className="text-slate-500 text-lg mb-8 leading-relaxed">Tu negocio ha sido validado por nuestra IA y cumple con todos los requisitos para fondearse.</p>
            <button className="btn-primary px-10 py-4 text-lg rounded-2xl">
              Ver Ofertas Disponibles
              <ArrowUpRight size={24} />
            </button>
          </div>
        </div>
        
        {/* Background Decoration */}
        <div className="absolute -right-20 -bottom-20 w-64 h-64 bg-emerald-50 rounded-full blur-3xl opacity-50" />
      </motion.div>

      {/* Grid de Acciones Rápidas (2x2) */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-6 mb-12">
        {[
          { label: 'Editar mi necesidad', icon: <Edit3 className="text-emerald-500" size={32} />, color: 'bg-emerald-50' },
          { label: 'Vincular mi banco', icon: <LinkIcon className="text-blue-500" size={32} />, color: 'bg-blue-50' },
          { label: 'Ver mis visitas', icon: <Users className="text-purple-500" size={32} />, color: 'bg-purple-50' },
          { label: 'Soporte IA', icon: <Activity className="text-orange-500" size={32} />, color: 'bg-orange-50' },
        ].map((action, i) => (
          <motion.button
            key={i}
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            className="glass-card flex flex-col items-center justify-center gap-4 p-8 text-center group rounded-[2rem]"
          >
            <div className={`w-16 h-16 rounded-2xl ${action.color} flex items-center justify-center transition-transform group-hover:rotate-6`}>
              {action.icon}
            </div>
            <span className="text-sm font-bold text-slate-700">{action.label}</span>
          </motion.button>
        ))}
      </div>

      <div className="grid lg:grid-cols-2 gap-8">
        {/* Activity Log */}
        <div className="glass-panel rounded-[2rem] p-8">
          <h3 className="text-xl font-bold mb-6 flex items-center gap-2 text-slate-900">
            <Activity size={20} className="text-emerald-500" />
            Movimientos Recientes
          </h3>
          <div className="space-y-6">
            {[
              { title: 'Solicitud Publicada', desc: 'Tu negocio ya es visible para inversionistas.', time: 'Hace 2h', icon: <CheckCircle2 className="text-emerald-500" /> },
              { title: 'Visita de Inversionista', desc: 'Un fondo institucional revisó tu perfil.', time: 'Hace 5h', icon: <Users className="text-blue-500" /> },
              { title: 'SafetyScore Actualizado', desc: 'Subiste 3 puntos por consistencia en ventas.', time: 'Ayer', icon: <TrendingUp className="text-emerald-500" /> },
            ].map((item, i) => (
              <div key={i} className="flex gap-4">
                <div className="mt-1">{item.icon}</div>
                <div>
                  <div className="text-sm font-bold text-slate-900">{item.title}</div>
                  <div className="text-xs text-slate-500 mb-1">{item.desc}</div>
                  <div className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">{item.time}</div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Quick Stats */}
        <div className="glass-panel rounded-[2rem] p-8">
          <h3 className="text-xl font-bold mb-6 flex items-center gap-2 text-slate-900">
            <TrendingUp size={20} className="text-emerald-500" />
            Tus Números
          </h3>
          <div className="space-y-4">
            <div className="p-6 rounded-2xl bg-slate-50 border border-slate-100">
              <div className="text-xs font-bold text-slate-400 uppercase tracking-widest mb-2">Ventas Promedio (Mes)</div>
              <div className="text-3xl font-black text-slate-900">$142,500</div>
            </div>
            <div className="p-6 rounded-2xl bg-emerald-50 border border-emerald-100">
              <div className="text-xs font-bold text-emerald-400 uppercase tracking-widest mb-2">Crecimiento Anual</div>
              <div className="text-3xl font-black text-emerald-500">+12.4%</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
