import React, { useState } from 'react';
import { motion } from 'motion/react';
import { Mail, Lock, User, ArrowRight, ShieldCheck, Github } from 'lucide-react';
import { View, Role } from '../../types';

interface AuthPageProps {
  onNavigate: (view: View) => void;
  onLogin: (role: Role) => void;
}

export const AuthPage: React.FC<AuthPageProps> = ({ onNavigate, onLogin }) => {
  const [isLogin, setIsLogin] = useState(true);
  const [role, setRole] = useState<Role>('pyme');

  return (
    <div className="min-h-screen bg-surface flex flex-col md:flex-row">
      {/* Left Side - Branding */}
      <div className="md:w-1/2 bg-slate-50 relative overflow-hidden flex flex-col justify-center p-12 lg:p-24 border-r border-slate-100">
        <div className="absolute inset-0 pointer-events-none">
          <div className="absolute top-[-20%] left-[-20%] w-[60%] h-[60%] bg-brand-blue/5 blur-[150px] rounded-full" />
          <div className="absolute bottom-[-20%] right-[-20%] w-[60%] h-[60%] bg-brand-red/5 blur-[150px] rounded-full" />
        </div>

        <div className="relative z-10">
          <div 
            className="flex items-center gap-2 mb-12 cursor-pointer"
            onClick={() => onNavigate('landing')}
          >
            <div className="w-10 h-10 bg-brand-blue rounded-xl flex items-center justify-center font-bold text-white text-xl">S</div>
            <span className="text-2xl font-display font-bold text-brand-blue">SafetyScore</span>
          </div>

          <h1 className="text-4xl lg:text-5xl font-display font-bold text-brand-blue mb-6 leading-tight">
            Accede a la nueva era de <br />
            <span className="text-brand-red">finanzas inteligentes.</span>
          </h1>
          
          <p className="text-lg text-slate-500 mb-12 max-w-md">
            Únete a cientos de negocios e inversionistas que ya están transformando el ecosistema financiero en Latinoamérica.
          </p>

          <div className="space-y-6">
            <div className="flex items-center gap-4 text-slate-600">
              <div className="w-10 h-10 rounded-full bg-white border border-slate-200 flex items-center justify-center text-brand-emerald shadow-sm">
                <ShieldCheck size={20} />
              </div>
              <span>Seguridad de grado bancario</span>
            </div>
            <div className="flex items-center gap-4 text-slate-600">
              <div className="w-10 h-10 rounded-full bg-white border border-slate-200 flex items-center justify-center text-brand-blue shadow-sm">
                <ShieldCheck size={20} />
              </div>
              <span>Verificación por IA en tiempo real</span>
            </div>
          </div>
        </div>
      </div>

      {/* Right Side - Form */}
      <div className="md:w-1/2 bg-surface flex flex-col justify-center p-8 lg:p-24">
        <div className="max-w-md w-full mx-auto">
          <div className="flex gap-8 mb-12 border-b border-slate-100">
            <button 
              onClick={() => setIsLogin(true)}
              className={`pb-4 text-lg font-semibold transition-all relative ${isLogin ? 'text-brand-blue' : 'text-slate-400'}`}
            >
              Iniciar Sesión
              {isLogin && <motion.div layoutId="tab" className="absolute bottom-0 left-0 w-full h-0.5 bg-brand-blue" />}
            </button>
            <button 
              onClick={() => setIsLogin(false)}
              className={`pb-4 text-lg font-semibold transition-all relative ${!isLogin ? 'text-brand-blue' : 'text-slate-400'}`}
            >
              Registrarse
              {!isLogin && <motion.div layoutId="tab" className="absolute bottom-0 left-0 w-full h-0.5 bg-brand-blue" />}
            </button>
          </div>

          {!isLogin && (
            <div className="grid grid-cols-2 gap-4 mb-8">
              <button 
                onClick={() => setRole('pyme')}
                className={`p-4 rounded-2xl border transition-all text-left ${role === 'pyme' ? 'border-brand-blue bg-brand-blue/5' : 'border-slate-200 hover:border-slate-300'}`}
              >
                <div className={`w-10 h-10 rounded-xl flex items-center justify-center mb-3 ${role === 'pyme' ? 'bg-brand-blue text-white' : 'bg-slate-100 text-slate-400'}`}>
                  <User size={20} />
                </div>
                <div className="font-bold text-brand-blue text-sm">Soy Negocio</div>
                <div className="text-xs text-slate-500">Busco inversión</div>
              </button>
              <button 
                onClick={() => setRole('investor')}
                className={`p-4 rounded-2xl border transition-all text-left ${role === 'investor' ? 'border-brand-blue bg-brand-blue/5' : 'border-slate-200 hover:border-slate-300'}`}
              >
                <div className={`w-10 h-10 rounded-xl flex items-center justify-center mb-3 ${role === 'investor' ? 'bg-brand-blue text-white' : 'bg-slate-100 text-slate-400'}`}>
                  <ShieldCheck size={20} />
                </div>
                <div className="font-bold text-brand-blue text-sm">Soy Inversionista</div>
                <div className="text-xs text-slate-500">Busco oportunidades</div>
              </button>
            </div>
          )}

          <form className="space-y-4" onSubmit={(e) => { e.preventDefault(); onLogin(role); }}>
            {!isLogin && (
              <div className="relative">
                <User className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-500" size={20} />
                <input type="text" placeholder="Nombre completo" className="input-field w-full pl-12" required />
              </div>
            )}
            <div className="relative">
              <Mail className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-500" size={20} />
              <input type="email" placeholder="Correo electrónico" className="input-field w-full pl-12" required />
            </div>
            <div className="relative">
              <Lock className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-500" size={20} />
              <input type="password" placeholder="Contraseña" className="input-field w-full pl-12" required />
            </div>

            {isLogin && (
              <div className="flex justify-end">
                <a href="#" className="text-sm text-brand-blue hover:underline">¿Olvidaste tu contraseña?</a>
              </div>
            )}

            <button type="submit" className="btn-primary w-full py-4 mt-4">
              {isLogin ? 'Entrar' : 'Crear Cuenta'}
              <ArrowRight size={20} />
            </button>
          </form>

          <div className="mt-8 flex items-center gap-4">
            <div className="flex-1 h-px bg-slate-100" />
            <span className="text-slate-400 text-sm">o continuar con</span>
            <div className="flex-1 h-px bg-slate-100" />
          </div>

          <div className="mt-8 grid grid-cols-2 gap-4">
            <button className="btn-outline py-3">
              <Github size={20} />
              Google
            </button>
            <button className="btn-outline py-3">
              <Github size={20} />
              LinkedIn
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
