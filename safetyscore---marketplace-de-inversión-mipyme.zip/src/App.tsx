/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { AnimatePresence, motion } from 'motion/react';
import { LandingPage } from './components/screens/LandingPage';
import { AuthPage } from './components/screens/AuthPage';
import { PymeDashboard } from './components/screens/PymeDashboard';
import { PymeWizard } from './components/screens/PymeWizard';
import { InvestorMarketplace } from './components/screens/InvestorMarketplace';
import { OpportunityDetail } from './components/screens/OpportunityDetail';
import { InvestorPortfolio } from './components/screens/InvestorPortfolio';
import { Sidebar } from './components/common/Sidebar';
import { View, Role, BusinessOpportunity } from './types';

export default function App() {
  const [view, setView] = useState<View>('landing');
  const [role, setRole] = useState<Role | null>(null);
  const [selectedOpportunity, setSelectedOpportunity] = useState<BusinessOpportunity | null>(null);

  useEffect(() => {
    if (role === 'investor') {
      document.documentElement.setAttribute('data-theme', 'investor');
    } else {
      document.documentElement.removeAttribute('data-theme');
    }
  }, [role]);

  const handleLogin = (userRole: Role) => {
    setRole(userRole);
    setView(userRole === 'pyme' ? 'pyme-dashboard' : 'investor-portfolio');
  };

  const handleLogout = () => {
    setRole(null);
    setView('landing');
  };

  const handleSelectOpportunity = (opp: BusinessOpportunity) => {
    setSelectedOpportunity(opp);
    setView('opportunity-detail');
  };

  const renderView = () => {
    switch (view) {
      case 'landing':
        return <LandingPage onNavigate={setView} />;
      case 'auth':
        return <AuthPage onNavigate={setView} onLogin={handleLogin} />;
      case 'pyme-dashboard':
        return <PymeDashboard />;
      case 'pyme-wizard':
        return <PymeWizard />;
      case 'investor-marketplace':
        return <InvestorMarketplace onSelectOpportunity={handleSelectOpportunity} />;
      case 'opportunity-detail':
        return selectedOpportunity ? (
          <OpportunityDetail 
            opportunity={selectedOpportunity} 
            onBack={() => setView('investor-marketplace')} 
          />
        ) : <InvestorMarketplace onSelectOpportunity={handleSelectOpportunity} />;
      case 'investor-portfolio':
        return <InvestorPortfolio />;
      default:
        return <LandingPage onNavigate={setView} />;
    }
  };

  const isDashboardView = role !== null && view !== 'landing' && view !== 'auth';

  return (
    <div className="min-h-screen">
      <AnimatePresence mode="wait">
        {isDashboardView ? (
          <div className="flex min-h-screen">
            <Sidebar 
              currentView={view} 
              onNavigate={setView} 
              role={role} 
              onLogout={handleLogout} 
            />
            <main className="flex-1 ml-72 p-8 lg:p-12 min-h-screen overflow-x-hidden">
              <motion.div
                key={view}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                transition={{ duration: 0.3 }}
              >
                {renderView()}
              </motion.div>
            </main>
          </div>
        ) : (
          <motion.div
            key={view}
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.4 }}
          >
            {renderView()}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}


