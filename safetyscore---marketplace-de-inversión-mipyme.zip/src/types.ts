export type View = 
  | 'landing' 
  | 'auth' 
  | 'pyme-dashboard' 
  | 'pyme-wizard' 
  | 'investor-marketplace' 
  | 'opportunity-detail' 
  | 'investor-portfolio';

export type Role = 'pyme' | 'investor';

export interface BusinessOpportunity {
  id: string;
  name: string;
  sector: string;
  location: string;
  safetyScore: number;
  roi: number;
  amount: number;
  term: number;
  fundedPercentage: number;
  status: 'new' | 'high-demand' | 'last-day';
  description: string;
  aiDictum: string;
}
